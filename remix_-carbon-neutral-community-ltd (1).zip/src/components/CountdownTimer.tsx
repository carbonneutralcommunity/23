import React, { useState, useEffect } from 'react';
import CNCLogo from './CNCLogo';

export default function CountdownTimer() {
  // Target date: June 12, 2026, 12:00 PM Sri Lanka Time (UTC 6:30 AM)
  const targetTime = new Date(Date.UTC(2026, 5, 12, 6, 30, 0)).getTime();

  const [timeLeft, setTimeLeft] = useState({
    days: '00',
    hours: '00',
    minutes: '00',
    seconds: '00',
  });

  // Calculate dynamic photosynthetic sync value
  const [photosyntheticSync, setPhotosyntheticSync] = useState(82.4);

  // Countdown clock loop
  useEffect(() => {
    function calculate() {
      const now = new Date().getTime();
      const distance = targetTime - now;

      if (distance < 0) {
        setTimeLeft({
          days: '00',
          hours: '00',
          minutes: '00',
          seconds: '00',
        });
        setPhotosyntheticSync(100);
        return;
      }

      const d = Math.floor(distance / (1000 * 60 * 60 * 24));
      const h = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const m = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
      const s = Math.floor((distance % (1000 * 60)) / 1000);

      setTimeLeft({
        days: d.toString().padStart(2, '0'),
        hours: h.toString().padStart(2, '0'),
        minutes: m.toString().padStart(2, '0'),
        seconds: s.toString().padStart(2, '0'),
      });

      // Gradually dynamic photosynthetic value syncing up towards launch
      const maxRange = 100 - 80;
      const progressRatio = Math.min(1, Math.max(0, 1 - (distance / (30 * 24 * 60 * 60 * 1000)))); // 30 day scale
      setPhotosyntheticSync(parseFloat((80 + (progressRatio * maxRange)).toFixed(2)));
    }

    calculate();
    const interval = setInterval(calculate, 1000);
    return () => clearInterval(interval);
  }, [targetTime]);

  return (
    <div 
      className="relative max-w-4xl w-full mx-auto mb-16 select-none animate-fade-in-up flex flex-col items-center gap-6"
      style={{ animationDelay: '0.2s' }}
      id="timer-tree-cell"
    >
      
      {/* Decorative Floating Forest Bioluminescence Sparkles */}
      <div className="absolute top-10 left-10 w-2 h-2 rounded-full bg-forest-mint/45 animate-ping pointer-events-none" />
      <div className="absolute bottom-12 right-12 w-2.5 h-2.5 rounded-full bg-neon-mint/45 animate-ping pointer-events-none" style={{ animationDuration: '3s' }} />

      {/* 2. THE GRAND BIOLOGICAL LEAF BACKDROP (Scale 100%) */}
      <div className="relative w-full aspect-square sm:aspect-video h-[350px] sm:h-[450px] md:h-[500px] rounded-3xl border border-emerald-500/25 bg-black/35 backdrop-blur-md overflow-hidden flex items-center justify-center shadow-[0_20px_50px_rgba(0,0,0,0.5),inset_0_2px_15px_rgba(116,198,157,0.15)] select-none">
        
        {/* Glowing atmospheric bio-fields behind the leaf */}
        <div className="absolute top-[20%] left-[50%] -translate-x-1/2 w-48 h-48 sm:w-64 sm:h-64 rounded-full bg-emerald-500/10 blur-[90px] animate-pulse pointer-events-none" />
        <div className="absolute top-[35%] left-[50%] -translate-x-1/2 w-56 h-56 sm:w-72 sm:h-72 rounded-full bg-neon-mint/10 blur-[100px] animate-breathing pointer-events-none" />

        {/* Majestic Glowing Horizontal Cloud Network SVG Outline */}
        <svg 
          className="absolute inset-0 w-full h-full pointer-events-none opacity-30 origin-center overflow-visible drop-shadow-[0_0_60px_rgba(146,214,164,0.35)] transition-all duration-1000 ease-in-out hover:scale-[1.01] scale-[1.4] translate-y-[10%]" 
          viewBox="0 0 240 240"
          preserveAspectRatio="none"
        >
          <defs>
            <linearGradient id="cloudGrad" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#ffffff" stopOpacity="0.45" />
              <stop offset="45%" stopColor="#a9dfbf" stopOpacity="0.25" />
              <stop offset="100%" stopColor="#114b2d" stopOpacity="0.05" />
            </linearGradient>
            <filter id="cloudEmeraldGlow">
              <feGaussianBlur stdDeviation="15" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          {/* Symmetrical glowing cloud envelope */}
          <path 
            d="M 50 145
               C 35 135, 30 110, 45 90
               C 45 70, 70 55, 95 60
               C 105 40, 135 40, 150 55
               C 170 45, 195 55, 195 75
               C 210 85, 215 110, 200 130
               C 195 145, 180 150, 165 145
               C 155 155, 85 155, 50 145 Z" 
            fill="url(#cloudGrad)"
            stroke="#74c69d"
            strokeWidth="1.5"
            strokeDasharray="4 4"
            filter="url(#cloudEmeraldGlow)"
            className="animate-pulse"
            style={{ animationDuration: '7s' }}
          />

          {/* Stratified cloud internal data-flow lines and air currents */}
          <path d="M 55 125 Q 120 120 185 125" fill="none" stroke="#52b788" strokeWidth="1" opacity="0.5" />
          <path d="M 75 105 Q 120 100 165 105" fill="none" stroke="#74c69d" strokeWidth="0.8" opacity="0.4" />
          <path d="M 95 85 Q 120 82 145 85" fill="none" stroke="#a9dfbf" strokeWidth="0.6" opacity="0.3" />

          {/* Glowing condensation/atmospheric telemetry nodes */}
          <circle cx="120" cy="50" r="3" fill="#d8f3dc" className="animate-pulse" style={{ animationDuration: '2.5s' }} />
          <circle cx="60" cy="98" r="2.5" fill="#a9dfbf" className="animate-ping" style={{ animationDuration: '3.2s' }} />
          <circle cx="180" cy="115" r="2.5" fill="#a9dfbf" className="animate-ping" style={{ animationDuration: '3.8s' }} />
          <circle cx="90" cy="72" r="2" fill="#74c69d" className="animate-pulse" style={{ animationDuration: '4.5s' }} />
          <circle cx="150" cy="78" r="2" fill="#74c69d" className="animate-pulse" style={{ animationDuration: '2.8s' }} />
        </svg>

        {/* 3. CORE COUNTDOWN TIMER GRID INSIDE THE CANOPY LEAF */}
        <div className="absolute z-10 w-full px-6 flex flex-col items-center">
          
          <div className="flex flex-col items-center text-center">
            <CNCLogo size={52} className="mb-4 rounded border border-emerald-500/20" interactive={true} />
            <span className="px-3 py-1 bg-forest-mint/20 border border-emerald-500/30 rounded-full font-label-sm text-[9px] tracking-[0.2em] text-[#74c69d] font-bold uppercase mb-3 inline-flex items-center gap-1.5 shadow-[inset_0_1px_5px_rgba(255,255,255,0.05)]">
              Verified Net-Zero Frontier
            </span>
            <h1 className="font-headline-md text-3xl sm:text-[45px] leading-tight font-black text-transparent bg-gradient-to-r from-white via-emerald-100 to-[#74c69d] bg-clip-text drop-shadow-[0_2px_12px_rgba(116,198,157,0.45)] tracking-tight">
              Carbon Neutral Launch
            </h1>
            <p className="font-body-md text-slate-300 text-xs sm:text-sm mt-2 max-w-md mx-auto leading-relaxed opacity-95 text-center">
              We are building a space for communities to unite, act, and thrive together toward a carbon neutral future. We launch very soon.
            </p>
          </div>

          <div className="grid grid-cols-4 gap-2 sm:gap-6 max-w-xl w-full mt-6 p-4 sm:p-5 rounded-3xl bg-white/[0.02] border border-white/10 hover:border-[#aef2bf]/40 backdrop-blur-2xl shadow-[0_20px_40px_rgba(0,0,0,0.4),inset_0_1px_1px_rgba(255,255,255,0.05)] hover:shadow-[0_25px_50px_rgba(146,214,164,0.15)] transition-all duration-500 hover:scale-[1.02] cursor-pointer active:scale-98 select-none">
            <div className="flex flex-col items-center p-2">
              <span className="font-headline-lg text-3xl sm:text-[48px] font-black text-neon-mint leading-none block drop-shadow-[0_0_10px_rgba(146,214,164,0.4)]">{timeLeft.days}</span>
              <span className="font-label-sm text-[9px] sm:text-[10px] text-white/55 tracking-widest uppercase mt-2 font-extrabold">Days</span>
            </div>
            <div className="flex flex-col items-center p-2">
              <span className="font-headline-lg text-3xl sm:text-[48px] font-black text-neon-mint leading-none block drop-shadow-[0_0_10px_rgba(146,214,164,0.4)]">{timeLeft.hours}</span>
              <span className="font-label-sm text-[9px] sm:text-[10px] text-white/55 tracking-widest uppercase mt-2 font-extrabold">Hours</span>
            </div>
            <div className="flex flex-col items-center p-2">
              <span className="font-headline-lg text-3xl sm:text-[48px] font-black text-[#a9dfbf] leading-none block drop-shadow-[0_0_10px_rgba(169,223,191,0.4)]">{timeLeft.minutes}</span>
              <span className="font-label-sm text-[9px] sm:text-[10px] text-white/55 tracking-widest uppercase mt-2 font-extrabold">Min</span>
            </div>
            <div className="flex flex-col items-center p-2">
              <span className="font-headline-lg text-3xl sm:text-[48px] font-black text-[#d8f3dc] leading-none block drop-shadow-[0_0_10px_rgba(216,243,220,0.4)]">{timeLeft.seconds}</span>
              <span className="font-label-sm text-[9px] sm:text-[10px] text-white/55 tracking-widest uppercase mt-2 font-extrabold">Sec</span>
            </div>
          </div>

          {/* Chlorophyll / Synthesis real-time dynamic sync value */}
          <div className="mt-8 bg-emerald-950/90 border border-emerald-500/35 px-4 py-1.5 rounded-full flex items-center gap-2 shadow-md">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
            <span className="font-label-sm text-[10px] text-white uppercase tracking-widest font-extrabold text-neon-mint">
              Chlorophyll Synthesis Sync: {photosyntheticSync}%
            </span>
          </div>

        </div>

      </div>

    </div>
  );
}
