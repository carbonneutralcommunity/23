import React, { useState, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { 
  Loader2, 
  Check, 
  UserCheck, 
  Trash2, 
  Activity, 
  ArrowRight, 
  ShieldCheck,
  Server,
  Sparkles
} from 'lucide-react';
import { Contributor } from '../types';
import { doc, getDoc, setDoc, deleteDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { playForestWindChime, playDewDrop, playOrganicTick, playSoftWarning } from '../utils/audio';

export default function NetworkRegistration() {
  const DEFAULT_COUNT = 4281;
  const [email, setEmail] = useState('');
  const [contributors, setContributors] = useState<Contributor[]>([]);
  const [status, setStatus] = useState<'idle' | 'success'>('idle');
  const [currentNodeId, setCurrentNodeId] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [showSuccessSparkles, setShowSuccessSparkles] = useState(false);

  // Sparkles appear 2 seconds after initialization
  useEffect(() => {
    if (status === 'success') {
      const timer = setTimeout(() => {
        setShowSuccessSparkles(true);
      }, 2000);
      return () => clearTimeout(timer);
    } else {
      setShowSuccessSparkles(false);
    }
  }, [status]);

  // Deep interactive terminal states
  const [showTerminal, setShowTerminal] = useState(false);
  const [terminalLogs, setTerminalLogs] = useState<{ text: string; type: 'info' | 'success' | 'warn' | 'cmd' }[]>([]);
  const [terminalDone, setTerminalDone] = useState(false);
  const [tempNodeId, setTempNodeId] = useState<string | null>(null);
  const [tempContributor, setTempContributor] = useState<Contributor | null>(null);
  const terminalBottomRef = useRef<HTMLDivElement | null>(null);

  // Auto-scroll the terminal logs
  useEffect(() => {
    if (terminalBottomRef.current) {
      terminalBottomRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [terminalLogs]);

  // Load configured local contributors
  useEffect(() => {
    try {
      const saved = localStorage.getItem('cnc_contributors');
      if (saved) {
        const parsed = JSON.parse(saved);
        setContributors(parsed);
      }
    } catch (e) {
      console.error("Failed to parse saved contributors", e);
    }
  }, []);

  const totalContributors = DEFAULT_COUNT + contributors.length;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanEmail = email.toLowerCase().trim();
    if (!cleanEmail || !cleanEmail.includes('@')) {
      setErrorMsg('PLEASE ENTER A VALID EMAIL ADDRESS');
      return;
    }
    setErrorMsg(null);
    setTerminalDone(false);
    setTerminalLogs([]);
    setShowTerminal(true);

    // Trigger majestic biophilic ambient wind chimes
    playForestWindChime();

    const log = (text: string, type: 'info' | 'success' | 'warn' | 'cmd' = 'info') => {
      setTerminalLogs(prev => [...prev, { text, type }]);
      
      // Play high-fidelity nature sound cues corresponding to current feedback stream
      if (type === 'success') {
        playDewDrop();
      } else if (type === 'warn') {
        playSoftWarning();
      } else {
        playOrganicTick();
      }
    };

    const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

    try {
      log(`$ sh cnc-subscriber-terminal@bio-grid.cnc.network -p 2026`, 'cmd');
      await sleep(400);
      log(`[SYS] SSL Handshake: TLS_AES_256_GCM_SHA384 connection established.`, 'info');
      await sleep(450);
      log(`[SYS] Security: Multi-layer Liquid Glass styling sandbox armed successfully.`, 'info');
      await sleep(500);
      log(`[CNC] INITIALIZING CARBON NEUTRAL INTEGRITY AUDIT...`, 'info');
      await sleep(450);
      log(`[POLICY] Activating net-zero compliance tracking protocols...`, 'info');
      await sleep(500);
      log(`[COMPLIANCE] Paris Agreement (Article 6.4) validation array connected.`, 'success');
      await sleep(450);
      log(`[GPS] Core location coordinates verified relative to biomass telemetry.`, 'info');
      await sleep(400);
      log(`[ALGORITHM] Initiating simulation models for CO2 sequestering...`, 'info');
      await sleep(550);
      log(`[LEDGER] Accessing decentralized Bio-Grid Registry...`, 'info');

      const docRef = doc(db, 'subscribers', cleanEmail);
      let existingDoc;
      try {
        existingDoc = await getDoc(docRef);
      } catch (err: any) {
        log(`[DATABASE] WARNING: Fetch failed. Checking offline cache layers.`, 'warn');
        if (err.code === 'permission-denied' || (err.message && err.message.includes('permission'))) {
          handleFirestoreError(err, OperationType.GET, `subscribers/${cleanEmail}`);
        }
        existingDoc = null; 
      }

      await sleep(650);

      if (existingDoc && existingDoc.exists()) {
        const data = existingDoc.data();
        const existingNodeId = data.nodeId;
        const existingJoinedAt = data.joinedAt;

        log(`[LEDGER] MATCH FOUND! Validated footprint profile: "${cleanEmail}"...`, 'success');
        await sleep(500);
        log(`[LEDGER] Synced node data associated with ID: ${existingNodeId}`, 'info');
        await sleep(450);
        log(`[CNC] RE-STABILIZING TELEMETRY ARRAYS RELATIVE TO CARBON COMPLIANCES...`, 'info');
        await sleep(400);
        log(`[STATUS] Handshake verification synced to carbon-credit quota registers.`, 'success');

        const foundContributor: Contributor = {
          email: cleanEmail,
          nodeId: existingNodeId,
          joinedAt: existingJoinedAt,
        };

        setTempNodeId(existingNodeId);
        setTempContributor(foundContributor);
      } else {
        log(`[LEDGER] Node registry scan finished: profile "${cleanEmail}" not registered.`, 'warn');
        await sleep(500);
        log(`[POLICY] Allocating fresh net-zero credit quota registers...`, 'info');
        await sleep(400);
        log(`[KEY_GEN] Creating cryptographic Bio-Grid node signature...`, 'info');

        const randNum = Math.floor(1000 + Math.random() * 9000);
        const newNodeId = `CNC-NODE-${randNum}`;
        const joinedAtTime = new Date().toISOString();

        await sleep(600);
        log(`[LEDGER] PROVISIONED NEW ADDRESS: ${newNodeId}`, 'success');
        await sleep(500);
        log(`[DATABASE] Committing secure JSON metadata to live cloud ledger...`, 'info');

        try {
          await setDoc(docRef, {
            email: cleanEmail,
            nodeId: newNodeId,
            joinedAt: joinedAtTime
          });
          log(`[DATABASE] Cloud write ACK: Registry synchronization SUCCESS.`, 'success');
        } catch (err: any) {
          log(`[DATABASE] ERROR: Failed to register live cloud endpoint. App will local-sync.`, 'warn');
          if (err.code === 'permission-denied' || (err.message && err.message.includes('permission'))) {
            handleFirestoreError(err, OperationType.WRITE, `subscribers/${cleanEmail}`);
          }
        }

        const newContributor: Contributor = {
          email: cleanEmail,
          nodeId: newNodeId,
          joinedAt: joinedAtTime,
        };

        setTempNodeId(newNodeId);
        setTempContributor(newContributor);
      }

      await sleep(500);
      log(`[COMPLIANCE] Re-verifying atmospheric carbon offsets thresholds...`, 'info');
      await sleep(450);
      log(`[STATUS] GREEN: All environment indicators are secure.`, 'success');
      await sleep(400);
      log(`[SYSTEM] Core handshake finished. Authorization complete.`, 'success');
      
      setTerminalDone(true);

    } catch (err: any) {
      console.error("Terminal sequence failed:", err);
      log(`[FATAL] CRITICAL CONFLICT IDENTIFIED: ${err.message || 'BIO-GRID OFFLINE'}`, 'warn');
      setErrorMsg(err.message || 'COULD NOT REGISTER NODE DIRECTLY.');
      setTerminalDone(true);
    }
  };

  const handleFinishTerminal = () => {
    if (tempContributor && tempNodeId) {
      const updated = [
        ...contributors.filter(c => c.email.toLowerCase() !== tempContributor.email.toLowerCase()),
        tempContributor
      ];
      setContributors(updated);
      localStorage.setItem('cnc_contributors', JSON.stringify(updated));
      setCurrentNodeId(tempNodeId);
      setStatus('success');
      playDewDrop();
    } else {
      setStatus('idle');
    }
    setShowTerminal(false);
  };

  const handleDeregister = async (emailToDeregister: string) => {
    const cleanEmail = emailToDeregister.toLowerCase().trim();
    
    try {
      await deleteDoc(doc(db, 'subscribers', cleanEmail));
    } catch (err: any) {
      console.warn("Failed to deactivate node from Firestore:", err);
      if (err.code === 'permission-denied' || (err.message && err.message.includes('permission'))) {
        handleFirestoreError(err, OperationType.DELETE, `subscribers/${cleanEmail}`);
      }
    }

    const updated = contributors.filter(c => c.email.toLowerCase() !== cleanEmail);
    setContributors(updated);
    localStorage.setItem('cnc_contributors', JSON.stringify(updated));
    
    if (email.toLowerCase().trim() === cleanEmail) {
      setStatus('idle');
      setEmail('');
      setCurrentNodeId(null);
    }
  };

  const handleReset = () => {
    setStatus('idle');
    setEmail('');
    setCurrentNodeId(null);
  };

  return (
    <div className="w-full max-w-4xl mx-auto mb-16 flex flex-col items-center gap-6" id="network-registration-engine">
      
      {/* CRT Secure Shell Terminal Portal */}
      {showTerminal && createPortal(
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/45 backdrop-blur-xl animate-fade-in">
          <div className="absolute top-1/4 left-1/4 w-72 h-72 rounded-full bg-neon-mint/10 blur-[100px] pointer-events-none animate-pulse" />
          <div className="absolute bottom-1/4 right-1/4 w-80 h-80 rounded-full bg-forest-mint/15 blur-[120px] pointer-events-none animate-pulse" style={{ animationDuration: '6s' }} />

          <div className="relative max-w-2xl w-full liquid-glass-modal p-6 md:p-8 flex flex-col h-[520px]">
            <div className="flex items-center justify-between border-b border-neon-mint/20 pb-4 mb-4 select-none">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-red-500/80 shadow-[0_0_8px_rgba(239,68,68,0.5)] border border-red-400/30"></span>
                <span className="w-3 h-3 rounded-full bg-yellow-500/80 shadow-[0_0_8px_rgba(234,179,8,0.5)] border border-yellow-400/30"></span>
                <span className="w-3 h-3 rounded-full bg-green-500/80 shadow-[0_0_8px_rgba(34,197,94,0.5)] border border-green-400/30"></span>
              </div>
              <span className="font-label-sm text-[10px] md:text-[11px] text-neon-mint/70 uppercase tracking-[0.2em] font-bold">
                CNC-SHELL // BIO-GRID SECURE BRIDGE
              </span>
              <div className="text-[10px] font-label-sm text-forest-mint/40">PORT:2026</div>
            </div>

            <div className="absolute inset-0 bg-gradient-to-b from-transparent via-white/[0.005] to-transparent pointer-events-none mix-blend-overlay rounded-xl"></div>

            <div className="flex-grow overflow-y-auto bg-black/40 backdrop-blur-md border border-neon-mint/15 p-4 font-label-sm rounded-xl space-y-2 text-xs md:text-sm text-white/90 text-left scrollbar-thin scrollbar-thumb-neon-mint/20">
              {terminalLogs.map((log, idx) => {
                const typeStyle = () => {
                  switch (log.type) {
                    case 'cmd':
                      return 'text-white font-semibold glow-pulse';
                    case 'success':
                      return 'text-emerald-400 font-medium';
                    case 'warn':
                      return 'text-yellow-400 font-medium animate-pulse';
                    case 'info':
                    default:
                      return 'text-forest-mint/90 font-medium';
                  }
                };

                return (
                  <div key={idx} className={`leading-relaxed break-all ${typeStyle()}`}>
                    {log.type === 'cmd' ? '' : '>>> '}{log.text}
                  </div>
                );
              })}
              
              {!terminalDone && (
                <div className="inline-flex items-center gap-1.5 text-neon-mint/70 animate-pulse text-xs md:text-sm pl-4 mt-2">
                  <Loader2 className="w-3.5 h-3.5 animate-spin text-neon-mint/85" />
                  <span>EXECUTING PARIS-AGREEMENT VALIDATIONS...</span>
                  <span className="w-1.5 h-4 bg-neon-mint rounded-sm animate-pulse"></span>
                </div>
              )}

              <div ref={terminalBottomRef} />
            </div>

            <div className="mt-5 flex justify-center">
              {terminalDone ? (
                <button
                  onClick={handleFinishTerminal}
                  className="w-full md:w-auto px-10 py-3.5 font-label-sm text-sm uppercase tracking-widest font-extrabold text-[#00210e] bg-gradient-to-r from-neon-mint via-forest-mint to-neon-mint border border-neon-mint hover:scale-105 active:scale-95 transition-all duration-300 shadow-[0_0_30px_rgba(146,214,164,0.6)] cursor-pointer hover:brightness-110 flex items-center justify-center gap-2 hover:shadow-[0_0_40px_rgba(116,198,157,0.85)]"
                >
                  <Check className="w-4 h-4" />
                  FINISH INITIALIZATION
                </button>
              ) : (
                <div className="py-2 inline-flex items-center gap-2 text-forest-mint/50 font-label-sm text-xs tracking-wider uppercase animate-pulse">
                  <span className="w-2 h-2 rounded-full bg-yellow-400 animate-ping"></span>
                  Node compliance in progress... Please do not close connection
                </div>
              )}
            </div>
          </div>
        </div>,
        document.body
      )}

      {/* Enter the Ecosystem UI Panel Section */}
      <div className="relative w-full rounded-3xl border border-emerald-500/15 bg-transparent p-8 md:p-12 flex flex-col items-center select-text">
        <div className="flex flex-col items-center text-center max-w-2xl">
          <span className="px-3 py-1 bg-forest-mint/20 border border-emerald-500/30 rounded-full font-label-sm text-[10px] tracking-widest text-[#74c69d] font-bold uppercase mb-4 inline-flex items-center gap-1.5">
            <Server className="w-3.5 h-3.5 animate-pulse text-neon-mint" />
            Decentralized Node Deployment
          </span>
          <h3 className="font-headline-md text-2xl sm:text-3.5xl font-black text-transparent bg-gradient-to-r from-white via-[#e8f5e9] to-[#74c69d] bg-clip-text drop-shadow-[0_2px_12px_rgba(116,198,157,0.45)] tracking-tight">
            Enter the Ecosystem
          </h3>
        </div>

        {/* Form Arena */}
        <div className="mt-8 w-full max-w-md bg-black/60 border border-emerald-500/20 p-6 rounded-2xl backdrop-blur-xl shadow-[0_15px_35px_rgba(0,0,0,0.65)] relative overflow-hidden">
          {/* Success Sparkle Overlays (appears after 2 seconds) */}
          {showSuccessSparkles && (
            <div className="absolute inset-0 pointer-events-none z-10 animate-fade-in">
              {/* Animating Sparkles at different corners */}
              <div className="absolute top-3 left-4 text-[#f5bf16] animate-pulse">
                <Sparkles className="w-5 h-5 drop-shadow-[0_0_8px_rgba(245,191,22,0.8)]" />
              </div>
              <div className="absolute bottom-4 right-5 text-neon-mint animate-pulse" style={{ animationDelay: '0.4s' }}>
                <Sparkles className="w-4 h-4 drop-shadow-[0_0_8px_rgba(146,214,164,0.8)]" />
              </div>
              <div className="absolute top-1/2 -right-1 text-emerald-400 opacity-60 animate-bounce" style={{ animationDuration: '3s' }}>
                <Sparkles className="w-3.5 h-3.5" />
              </div>
              <div className="absolute bottom-1/3 left-3 text-[#f5bf16] opacity-75 animate-pulse" style={{ animationDelay: '0.8s' }}>
                <Sparkles className="w-4 h-4 drop-shadow-[0_0_6px_rgba(245,191,22,0.6)]" />
              </div>
              {/* Shimmering Golden-Emerald Ambient Border glow */}
              <div className="absolute inset-0 border border-yellow-500/35 rounded-2xl animate-pulse pointer-events-none shadow-[0_0_15px_rgba(245,191,22,0.15)]" style={{ animationDuration: '2.5s' }} />
            </div>
          )}

          {status === 'idle' && (
            <form onSubmit={handleSubmit} className="flex flex-col gap-3.5 relative">
              <div className="relative">
                <input
                  className="w-full bg-black/35 backdrop-blur-md border border-emerald-500/40 text-white p-3.5 focus:outline-none focus:border-neon-mint focus:ring-1 focus:ring-neon-mint placeholder:text-white/25 font-mono text-xs tracking-wider rounded-xl transition-all duration-300 text-center"
                  placeholder="YOUR@ORGANIC.EMAIL"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              <button
                type="submit"
                className="w-full py-3.5 font-label-sm font-extrabold uppercase tracking-widest bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-neon-mint hover:to-[#52b788] text-primary transition-all duration-300 rounded-xl hover:cursor-pointer shadow-[0_4px_15px_rgba(82,183,136,0.2)] hover:shadow-[0_4px_25px_rgba(116,198,157,0.65)] hover:scale-[1.02] active:scale-95 text-xs flex items-center justify-center gap-1.5 text-black"
              >
                <span>Initialize Connection</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </form>
          )}

          {/* Success Slate */}
          {status === 'success' && (
            <div className="text-center space-y-4 animate-fade-in">
              <div className="flex justify-center">
                <div className="w-10 h-10 bg-[#0c3116] rounded-full border border-neon-mint flex items-center justify-center shadow-[0_0_15px_rgba(116,198,157,0.4)]">
                  <Check className="text-neon-mint w-5 h-5 animate-bounce" />
                </div>
              </div>
              <div>
                <h4 className="font-label-sm text-sm text-neon-mint font-black uppercase tracking-wider">
                  Secure Node Synchronized
                </h4>
                <p className="font-body-md text-[11px] text-white/70 mt-1 max-w-[280px] mx-auto leading-relaxed">
                  Account <span className="text-emerald-300 font-medium">{email}</span> is now fully synchronized to the bio-ledger.
                </p>
              </div>

              <div className="bg-[#02170d] border border-emerald-500/25 p-3 rounded-lg flex flex-col gap-2 shadow-[inset_0_2px_10px_rgba(0,0,0,0.6)]">
                <div className="flex justify-between items-center text-left">
                  <span className="text-[9px] font-mono text-emerald-400 opacity-60">NODE_SIGNATURE</span>
                  <span className="text-xs font-mono text-white font-bold tracking-widest select-all">{currentNodeId}</span>
                </div>
                <div className="flex justify-between items-center text-left border-t border-emerald-500/10 pt-1.5">
                  <span className="text-[9px] font-mono text-emerald-400 opacity-60">STATUS_SECURE</span>
                  <span className="text-[10px] font-mono text-neon-mint flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                    LIVE & SECURING
                  </span>
                </div>
              </div>

              <div className="flex gap-2 justify-center pt-1.5">
                <button
                  onClick={handleReset}
                  className="px-4 py-2 bg-white/5 hover:bg-white/10 text-emerald-300 border border-emerald-500/25 font-label-sm text-[10px] uppercase tracking-wider transition-all rounded-lg cursor-pointer"
                >
                  Register New
                </button>
                <button
                  onClick={() => handleDeregister(email)}
                  className="px-4 py-2 bg-red-950/20 hover:bg-red-950/40 text-red-300 border border-red-900/30 font-label-sm text-[10px] uppercase tracking-wider transition-all rounded-lg flex items-center gap-1 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Deactivate
                </button>
              </div>
            </div>
          )}

          {errorMsg && (
            <p className="mt-3 font-mono text-red-400 text-[10px] border border-red-900/40 bg-red-950/20 p-2 rounded-lg uppercase tracking-wider text-center">
              {errorMsg}
            </p>
          )}
        </div>

        {/* Active registry list at the bottom of form panel */}
        {contributors.length > 0 && (
          <div className="w-full text-left border-t border-white/5 pt-6 mt-8 select-text">
            <h5 className="font-label-sm text-primary-fixed/80 text-xs uppercase tracking-widest mb-3 flex items-center gap-2 font-black">
              <UserCheck className="w-4 h-4 text-[#74c69d]" />
              Active Local Node Registry ({contributors.length})
            </h5>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 max-h-36 overflow-y-auto pr-1">
              {contributors.map((c, idx) => (
                <div 
                  key={idx} 
                  className="flex items-center justify-between text-xs font-mono bg-white/[0.02] border border-white/5 p-2 rounded-lg hover:bg-white/[0.04] transition-all"
                >
                  <div className="truncate pr-2">
                    <span className="text-[#a9dfbf] font-bold mr-1 select-all">{c.nodeId}</span>
                    <span className="text-white/45 truncate text-[10px]">{c.email}</span>
                  </div>
                  <button
                    onClick={() => handleDeregister(c.email)}
                    className="text-white/30 hover:text-red-400 transition-all p-1 cursor-pointer"
                    title="Remove local registry"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
