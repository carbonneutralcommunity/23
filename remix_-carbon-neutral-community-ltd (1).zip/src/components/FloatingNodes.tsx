import React, { useState, useEffect } from 'react';
import { Leaf, Activity, Globe, Sun } from 'lucide-react';
import { FloatingNodeData } from '../types';

interface FloatingNodesProps {
  mouseOffset: { x: number; y: number };
}

export default function FloatingNodes({ mouseOffset }: FloatingNodesProps) {
  const [activeNode, setActiveNode] = useState<string | null>(null);

  // Close active nodes when clicking anywhere else on the document
  useEffect(() => {
    const handleDocumentClick = () => {
      setActiveNode(null);
    };

    document.addEventListener('click', handleDocumentClick);
    return () => {
      document.removeEventListener('click', handleDocumentClick);
    };
  }, []);

  const nodes: FloatingNodeData[] = [
    {
      id: 'eco-growth',
      title: 'Eco-Growth',
      description: 'Scalable carbon capture models driven by community governance and distributed ledgers.',
      iconName: 'Leaf',
      positionStyle: { top: '20%', left: '10%' },
      speed: 30,
    },
    {
      id: 'green-vital',
      title: 'Green-Vital',
      description: 'Real-time health monitoring and growth evaluation of local reforestation projects.',
      iconName: 'Activity',
      positionStyle: { top: '65%', left: '5%' },
      speed: 60,
    },
    {
      id: 'terra-plus',
      title: 'Terra-Plus',
      description: 'Incentivized biodiversity restoration through verified spatial data and volunteer nodes.',
      iconName: 'Globe',
      positionStyle: { top: '25%', right: '10%' },
      speed: 90,
    } as any, // Position style has either left or right
    {
      id: 'solar-comm',
      title: 'Solar-Comm',
      description: 'Decentralized sustainable energy microgrids and micro-distribution shared across the community.',
      iconName: 'Sun',
      positionStyle: { bottom: '25%', right: '15%' },
      speed: 120,
    } as any,
  ];

  const handleNodeClick = (e: React.MouseEvent, nodeId: string) => {
    e.stopPropagation(); // Prevent the global document click listener from firing
    setActiveNode(activeNode === nodeId ? null : nodeId);
  };

  return (
    <div className="absolute inset-0 w-full h-full pointer-events-none z-35">
      {nodes.map((node) => {
        // Render appropriate Lucide icon
        const renderIcon = () => {
          const iconClass = "text-primary-fixed w-5 h-5 md:w-6 md:h-6 transition-all group-hover:scale-110";
          switch (node.iconName) {
            case 'Leaf':
              return <Leaf className={iconClass} />;
            case 'Activity':
              return <Activity className={iconClass} />;
            case 'Globe':
              return <Globe className={iconClass} />;
            case 'Sun':
              return <Sun className={iconClass} />;
          }
        };

        // Standard parallax translation
        const xOffset = mouseOffset.x * node.speed;
        const yOffset = mouseOffset.y * node.speed;

        const combinedStyle = {
          transform: `translate(${xOffset}px, ${yOffset}px)`,
          top: node.positionStyle.top,
          left: node.positionStyle.left,
          right: node.positionStyle.right,
          bottom: node.positionStyle.bottom,
        };

        const isOpen = activeNode === node.id;

        return (
          <div
            key={node.id}
            className={`absolute pointer-events-auto group transition-transform duration-300 ease-out ${
              isOpen ? 'z-50 shadow-2xl scale-105' : 'z-30'
            }`}
            style={combinedStyle}
          >
            {/* The Floating Glow Node Circle */}
            <button
              onClick={(e) => handleNodeClick(e, node.id)}
              className={`glow-node w-11 h-11 md:w-12 md:h-12 rounded-full border border-primary-fixed/50 bg-primary/90 backdrop-blur-md flex items-center justify-center cursor-pointer hover:shadow-[0_0_35px_rgba(148,214,164,0.8)] focus:outline-none focus:ring-2 focus:ring-primary-fixed/50 ${
                isOpen ? 'scale-110 border-primary-fixed shadow-[0_0_35px_rgba(148,214,164,0.8)]' : ''
              }`}
              title={`Click to view ${node.title}`}
            >
              {renderIcon()}
            </button>

            {/* Hover Glass Panel description (responsive support) */}
            <div
              onClick={(e) => e.stopPropagation()} // Stop click events on the popup itself from reaching the document and closing it
              className={`glass-panel absolute p-5 rounded-xl pointer-events-none transition-all duration-300 backdrop-blur-lg bg-black/60 border-primary-fixed/30 text-left z-50 shadow-2xl ${
                node.positionStyle.right ? '-left-56 md:-left-64' : 'left-14 md:left-16'
              } top-[-20%] w-[240px] md:w-[280px] ${
                isOpen ? 'opacity-100 translate-y-0 scale-100 pointer-events-auto' : 'opacity-0 translate-y-2 scale-95 md:group-hover:opacity-100 md:group-hover:translate-y-0 md:group-hover:scale-100'
              }`}
            >
              <div className="flex items-center gap-2 mb-2">
                <span className="w-1.5 h-1.5 rounded-full bg-forest-mint animate-pulse"></span>
                <h4 className="font-label-sm text-primary-fixed uppercase tracking-wider text-xs font-bold">
                  {node.title}
                </h4>
              </div>
              <p className="font-body-md text-xs text-white/90 leading-relaxed">
                {node.description}
              </p>
              
              {isOpen && (
                <div className="mt-3 text-[10px] font-label-sm text-primary-fixed/60 border-t border-primary-fixed/15 pt-2 flex justify-between items-center">
                  <span>ACTIVE CONNECTIONS: 34</span>
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveNode(null);
                    }}
                    className="hover:text-white transition-colors underline pointer-events-auto cursor-pointer"
                  >
                    Close
                  </button>
                </div>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
