import React, { useState } from 'react';

interface CNCLogoProps {
  size?: number | string;
  className?: string;
  inverted?: boolean;
  interactive?: boolean;
}

export default function CNCLogo({ size = 48, className = '', inverted = false, interactive = false }: CNCLogoProps) {
  const [internalInverted, setInternalInverted] = useState(inverted);

  // Brand Colors
  const greenColor = '#003b1d'; // --color-primary / Deep forest green
  const yellowColor = '#f5bf16'; // --color-secondary-fixed-dim / Vibrant gold-yellow
  
  const frameColor = internalInverted ? yellowColor : greenColor;
  const innerBgColor = internalInverted ? greenColor : yellowColor;
  const textColor = internalInverted ? yellowColor : greenColor;

  const handleInteraction = () => {
    if (interactive) {
      setInternalInverted(prev => !prev);
    }
  };

  const renderSVGContents = () => (
    <>
      {/* Outer Thick Green Frame */}
      <rect
        x="5"
        y="5"
        width="110"
        height="110"
        fill={frameColor}
        className="transition-colors duration-500"
      />

      {/* Inner Yellow Background Square */}
      <rect
        x="18"
        y="18"
        width="84"
        height="84"
        fill={innerBgColor}
        className="transition-colors duration-500"
      />

      {/* Parallel Slanted White Stripes at the Top (angled at ~60 deg, cutting through top frame) */}
      <g opacity="0.95">
        <polygon
          points="83,5 96,5 82,34 69,34"
          fill="#FFFFFF"
        />
        <polygon
          points="97,5 110,5 96,34 83,34"
          fill="#FFFFFF"
        />
      </g>

      {/* Beautiful Custom "cnc" Logo Vector Paths - Hand-optimized bezier curves
          Designed to match the stylized lowercase interconnected text & long 'n' tail */}
      <path
        d="
          M 47,56 
          C 43,47 34,44 26,51 
          17,58 17,73 26,80 
          33,85 41,83 45,74
          M 45,74 
          C 47,68 47,60 48,53
          C 49,43 57,41 62,49
          C 66,54 66,61 66,68
          C 66,78 66,88 66,97
          C 66,105 60,111 48,111
          C 42,111 36,108 34,105
          M 66,68
          C 70,55 77,44 86,51
          C 94,57 93,73 86,80
          C 79,86 71,83 67,75
        "
        stroke={textColor}
        strokeWidth="6.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="transition-colors duration-500"
      />
    </>
  );

  if (interactive) {
    return (
      <div 
        className={`relative inline-block cursor-pointer transition-all duration-500 select-none ${className}`}
        onMouseEnter={() => setInternalInverted(!inverted)}
        onMouseLeave={() => setInternalInverted(inverted)}
        onClick={handleInteraction}
        style={{ width: size, height: size }}
        title="Interactive Brand Logo (Hover/Click to toggle vice-versa!)"
      >
        <div className="w-full h-full [perspective:1000px]">
          <div className={`relative w-full h-full transition-transform duration-500 [transform-style:preserve-3d] ${internalInverted !== inverted ? '[transform:rotateY(180deg)]' : ''}`}>
            {/* Front Side */}
            <div className="absolute inset-0 [backface-visibility:hidden]">
              <svg
                width="100%"
                height="100%"
                viewBox="0 0 120 120"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                {renderSVGContents()}
              </svg>
            </div>
            {/* Back Side (Inverted / vice versa) */}
            <div className="absolute inset-0 [backface-visibility:hidden] [transform:rotateY(180deg)]">
              <svg
                width="100%"
                height="100%"
                viewBox="0 0 120 120"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                {renderSVGContents()}
              </svg>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 120 120"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`inline-block select-none ${className}`}
      style={{ minWidth: typeof size === 'number' ? `${size}px` : '32px' }}
    >
      {renderSVGContents()}
    </svg>
  );
}
