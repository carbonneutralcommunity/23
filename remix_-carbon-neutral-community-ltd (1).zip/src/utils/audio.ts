let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    // Standard and legacy audio context support
    audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

/**
 * Play a soothing forest wind chime wash.
 * Perfect for initial terminal activation, signaling natural energy and net-zero.
 */
export function playForestWindChime() {
  const ctx = getAudioContext();
  if (!ctx) return;

  const now = ctx.currentTime;

  // 1. Generate ambient low-frequency forest wind rustle using dynamic white noise
  const bufferSize = ctx.sampleRate * 2.5; // 2.5 seconds clip
  const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < bufferSize; i++) {
    data[i] = Math.random() * 2 - 1; // Pure white noise
  }

  const noiseNode = ctx.createBufferSource();
  noiseNode.buffer = buffer;

  const noiseFilter = ctx.createBiquadFilter();
  noiseFilter.type = 'lowpass';
  noiseFilter.frequency.setValueAtTime(140, now);
  noiseFilter.frequency.exponentialRampToValueAtTime(320, now + 1.2);
  noiseFilter.Q.setValueAtTime(1.5, now);

  const noiseGain = ctx.createGain();
  noiseGain.gain.setValueAtTime(0, now);
  noiseGain.gain.linearRampToValueAtTime(0.03, now + 0.4); // soft wind breeze fade-in
  noiseGain.gain.exponentialRampToValueAtTime(0.0001, now + 2.3); // breeze fade-out

  noiseNode.connect(noiseFilter);
  noiseFilter.connect(noiseGain);
  noiseGain.connect(ctx.destination);
  noiseNode.start(now);

  // 2. Play wind catching beautiful mineral chimes - using organic soft pentatonic notes
  // D4, E4, G4, A4, D5 are inherently forest-like and meditative frequencies
  const pentatonicFrequencies = [293.66, 329.63, 392.00, 440.00, 587.33];
  
  pentatonicFrequencies.forEach((freq, idx) => {
    // Stagger chiming moments slightly to sound like wind gusts moving individual tines
    const noteTime = now + (idx * 0.18) + Math.random() * 0.12;
    const noteDuration = 2.4 - (idx * 0.1);

    const osc = ctx.createOscillator();
    const oscGain = ctx.createGain();
    const resonanceFilter = ctx.createBiquadFilter();

    // Alternate wave shapes to create dynamic richness (wind chime and wood logs)
    osc.type = idx % 2 === 0 ? 'sine' : 'triangle';
    osc.frequency.setValueAtTime(freq, noteTime);

    // Warm, low-pass filter to make it sound non-intrusive and soothingly round
    resonanceFilter.type = 'lowpass';
    resonanceFilter.frequency.setValueAtTime(freq * 1.8, noteTime);

    // Gentle physical strike envelope
    oscGain.gain.setValueAtTime(0, noteTime);
    oscGain.gain.linearRampToValueAtTime(0.04, noteTime + 0.2); // strike swell
    oscGain.gain.exponentialRampToValueAtTime(0.0001, noteTime + noteDuration); // long warm tail

    osc.connect(resonanceFilter);
    resonanceFilter.connect(oscGain);
    oscGain.connect(ctx.destination);

    osc.start(noteTime);
    osc.stop(noteTime + noteDuration);
  });
}

/**
 * Play an organic liquid dew drop splash sound.
 * Excellent for successful integrations, successful node updates, or milestone accomplishments.
 */
export function playDewDrop() {
  const ctx = getAudioContext();
  if (!ctx) return;

  const now = ctx.currentTime;

  const osc = ctx.createOscillator();
  const gainNode = ctx.createGain();
  const resonanceFilter = ctx.createBiquadFilter();

  osc.type = 'sine';
  // Rapid vertical logarithmic pitch curve simulating water drop impact and capillary rebound
  osc.frequency.setValueAtTime(950, now);
  osc.frequency.exponentialRampToValueAtTime(450, now + 0.14);

  resonanceFilter.type = 'lowpass';
  resonanceFilter.frequency.setValueAtTime(1600, now);

  gainNode.gain.setValueAtTime(0.001, now);
  gainNode.gain.linearRampToValueAtTime(0.12, now + 0.015); // instant soft splash
  gainNode.gain.exponentialRampToValueAtTime(0.0001, now + 0.24); // smooth fluid decay

  osc.connect(resonanceFilter);
  resonanceFilter.connect(gainNode);
  gainNode.connect(ctx.destination);

  osc.start(now);
  osc.stop(now + 0.26);
}

/**
 * Play a biophilic organic wooden percussion tick.
 * Excellent to pair with active terminal printing to represent data packets and eco policies.
 */
export function playOrganicTick() {
  const ctx = getAudioContext();
  if (!ctx) return;

  const now = ctx.currentTime;

  const osc = ctx.createOscillator();
  const gainNode = ctx.createGain();
  const bandpass = ctx.createBiquadFilter();

  // Simulating small dry wood or bamboo click
  osc.type = 'triangle';
  osc.frequency.setValueAtTime(220, now);
  osc.frequency.exponentialRampToValueAtTime(320, now + 0.02);

  bandpass.type = 'bandpass';
  bandpass.frequency.setValueAtTime(400, now);
  bandpass.Q.setValueAtTime(10, now);

  gainNode.gain.setValueAtTime(0.001, now);
  gainNode.gain.linearRampToValueAtTime(0.04, now + 0.003); // crispy pluck
  gainNode.gain.exponentialRampToValueAtTime(0.0001, now + 0.05); // very short wooden click decay

  osc.connect(bandpass);
  bandpass.connect(gainNode);
  gainNode.connect(ctx.destination);

  osc.start(now);
  osc.stop(now + 0.06);
}

/**
 * Play a warm soft alert chime for warning logs or errors.
 */
export function playSoftWarning() {
  const ctx = getAudioContext();
  if (!ctx) return;

  const now = ctx.currentTime;

  const osc = ctx.createOscillator();
  const gainNode = ctx.createGain();

  osc.type = 'triangle';
  osc.frequency.setValueAtTime(220, now);
  osc.frequency.setValueAtTime(180, now + 0.15); // gentle dual-tone warning indicator

  gainNode.gain.setValueAtTime(0.001, now);
  gainNode.gain.linearRampToValueAtTime(0.05, now + 0.05);
  gainNode.gain.linearRampToValueAtTime(0.05, now + 0.2);
  gainNode.gain.exponentialRampToValueAtTime(0.0001, now + 0.4);

  osc.connect(gainNode);
  gainNode.connect(ctx.destination);

  osc.start(now);
  osc.stop(now + 0.45);
}
