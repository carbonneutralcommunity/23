import { useState, useEffect } from 'react';
import { 
  Facebook, 
  Mail, 
  Globe, 
  BookOpen, 
  Leaf, 
  HeartHandshake, 
  TreePine, 
  ChevronRight, 
  X, 
  Sparkles 
} from 'lucide-react';
import CountdownTimer from './components/CountdownTimer';
import FloatingNodes from './components/FloatingNodes';
import NetworkRegistration from './components/NetworkRegistration';
import CNCLogo from './components/CNCLogo';

export default function App() {
  const [mouseOffset, setMouseOffset] = useState({ x: 0, y: 0 });
  const [showEcosystemModal, setShowEcosystemModal] = useState(false);

  // Mouse Parallax for Nodes and Background
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const mouseX = e.clientX / window.innerWidth;
      const mouseY = e.clientY / window.innerHeight;
      
      // Relative offset from center (-0.5 to 0.5)
      setMouseOffset({
        x: mouseX - 0.5,
        y: mouseY - 0.5,
      });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  return (
    <div className="bg-primary text-on-primary selection:bg-primary-fixed selection:text-primary min-h-screen relative font-body-md overflow-x-hidden flex flex-col justify-between">
      
      {/* Background Layer with Parallax */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-black/45 z-10 pointer-events-none"></div>
        <img 
          alt="Lush rainforest canopy" 
          className="w-full h-full object-cover transition-transform duration-200 ease-out" 
          id="bg-image" 
          src="https://lh3.googleusercontent.com/aida-public/AB6AXuDV19FJVQZkqN6C4zoP7eVkWmBsDawTbqeGeDmS8W6m3jsGlVGTOBrNQtbpzr0pt-wfastzfoKFByl1XLkPtzA7nDvNBrwe81SmPHD3qc3EuhM7TLbliL4W4nv1iEaprR0LkJyvnuX3dvGh4aBH42Zye4rB3zU1UW4Kbbn3IIHtei3AjyNWhQW00kmjYDQWArH6IwXYyrcnOx5PoUxhGZqGAGp_rONlV7DnZbBE00ZBaYpnc_Q39kE4sd8BsHSCcjz_4CH3hd7F8ag" 
          style={{
            transform: `scale(1.1) translate(${mouseOffset.x * 20}px, ${mouseOffset.y * 20}px)`,
            willChange: 'transform',
          }}
        />
      </div>

      {/* Navigation Shell */}
      <header className="relative z-50 w-full top-0 bg-transparent flex justify-between items-center py-6 px-6 md:px-16 max-w-7xl mx-auto animate-fade-in-up">
        <div className="flex items-center gap-3">
          <CNCLogo size={36} className="rounded border border-emerald-500/20" interactive={true} />
          <span className="font-headline-md text-base sm:text-lg md:text-xl lg:text-2xl font-bold text-transparent bg-gradient-to-r from-forest-mint via-neon-mint to-primary-fixed bg-clip-text drop-shadow-[0_2px_10px_rgba(183,228,199,0.35)] tracking-tight hover:brightness-110 transition-all duration-300">
            Carbon Neutral Community
          </span>
        </div>
        
        <nav className="flex gap-4 md:gap-8 items-center">
          <button 
            onClick={() => setShowEcosystemModal(true)}
            className="font-label-sm text-primary-fixed hover:text-white transition-all cursor-pointer flex items-center gap-1.5 focus:outline-none"
          >
            <BookOpen className="w-4 h-4" />
            <span className="border-b-2 border-transparent hover:border-primary-fixed pb-0.5">Ecosystem</span>
          </button>
          
          <a hred="https://facebook.com/profile.php?id=61590561419379" href="https://facebook.com/profile.php?id=61590561419379" target="_blank" rel="noopener noreferrer">
            <button className="px-5 py-2.5 border border-primary-fixed/50 font-label-sm text-xs uppercase tracking-widest transition-all duration-300 bg-white/5 backdrop-blur-md text-primary-fixed hover:bg-primary-fixed/20 hover:border-primary-fixed hover:scale-105 hover:shadow-[0_0_25px_rgba(148,214,164,0.5)] rounded-sm cursor-pointer">
              Join Hub
            </button>
          </a>
        </nav>
      </header>

      {/* Main Grid View */}
      <main className="relative z-10 w-full max-w-7xl mx-auto flex-grow flex flex-col items-center justify-center py-10 px-4 md:px-8">
        
        {/* Countdown Center Circle */}
        <CountdownTimer />

        {/* Registration Console */}
        <NetworkRegistration />

        {/* Floating/Parallax Nodes */}
        <FloatingNodes mouseOffset={mouseOffset} />

      </main>

      {/* Footer Shell */}
      <footer className="relative z-50 glass-panel backdrop-blur-md mx-4 md:mx-16 mb-8 rounded-lg border border-primary-fixed/30 animate-fade-in-up max-w-7xl xl:mx-auto xl:w-full" style={{ animationDelay: '0.6s' }}>
        <div className="flex flex-col md:flex-row justify-between items-center px-6 md:px-16 py-12">
          
          <div className="mb-8 md:mb-0 text-center md:text-left flex flex-col md:flex-row items-center gap-4">
            <CNCLogo size={42} inverted={true} className="rounded border border-yellow-500/10" interactive={true} />
            <div>
              <span className="text-primary-fixed font-headline-md text-base md:text-lg font-bold uppercase tracking-tighter">
                Carbon Neutral Community
              </span>
              <p className="font-label-sm text-white/40 mt-1.5 text-xs">
                © 2026 Carbon Neutral Community LTD. All rights reserved.
              </p>
            </div>
          </div>
          
          <div className="flex flex-col items-center md:items-end gap-6">
            <div className="flex flex-wrap justify-center md:justify-end gap-6 items-center">
              
              <a 
                className="text-primary-fixed hover:text-white hover:scale-105 transition-all flex items-center gap-2" 
                href="https://facebook.com/profile.php?id=61590561419379" 
                target="_blank" 
                rel="noreferrer"
              >
                <Facebook className="w-4 h-4" />
                <span className="font-label-sm uppercase tracking-widest text-[10px] md:text-xs">
                  Facebook
                </span>
              </a>
              
              <a 
                className="text-primary-fixed hover:text-white hover:scale-105 transition-all flex items-center gap-2" 
                href="mailto:carbonneutralcommunity@gmail.com"
              >
                <Mail className="w-4 h-4" />
                <span className="font-label-sm uppercase tracking-widest text-[10px] md:text-xs">
                  Email
                </span>
              </a>
              
              <a 
                className="font-label-sm text-primary-fixed hover:text-white hover:scale-105 transition-all uppercase tracking-widest text-[10px] md:text-xs pb-0.5 no-underline flex items-center gap-1" 
                href="https://carbonneutralcommunity.org" 
                target="_blank" 
                rel="noreferrer"
              >
                <Globe className="w-3.5 h-3.5" />
                Our Community
              </a>

            </div>
          </div>
        </div>
      </footer>

      {/* Ecosystem Modal Dialog */}
      {showEcosystemModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xl animate-fade-in">
          <div 
            className="w-full max-w-2xl liquid-glass-modal p-6 md:p-8 text-left relative animate-fade-in-up"
            style={{ animationDuration: '0.3s' }}
          >
            <button 
              onClick={() => setShowEcosystemModal(false)}
              className="absolute top-4 right-4 text-white/50 hover:text-white hover:bg-white/10 rounded-full p-1.5 transition-colors focus:outline-none"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-6 border-b border-primary-fixed/20 pb-4">
              <Leaf className="text-primary-fixed w-6 h-6 animate-pulse" />
              <h3 className="font-headline-md text-xl md:text-2xl text-primary-fixed font-bold tracking-tight">
                Our Ecosystem Mission
              </h3>
            </div>

            <p className="font-body-md text-slate-300 text-sm md:text-base leading-relaxed mb-6">
              The Carbon Neutral Community LTD coordinates verified bio-monitoring data nodes, scalable ecological growth indicators, and communal solar networks to empower citizens to actively monitor and execute verified offset transformations.
            </p>

            <h4 className="font-label-sm text-primary-fixed/80 text-xs tracking-widest uppercase mb-4">
              Core Strategic Pillars
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
              
              <div className="p-4 bg-black/40 border border-emerald-500/20 rounded-2xl hover:border-emerald-500/40 hover:bg-black/60 transition-all duration-300 backdrop-blur-md">
                <div className="flex items-center gap-2 mb-2">
                  <TreePine className="text-neon-mint w-4 h-4 animate-pulse" />
                  <span className="font-label-sm text-xs font-bold text-white uppercase">Eco-Growth</span>
                </div>
                <p className="text-white/70 text-xs">
                  We empower communities to invest in scalable carbon storage plantations overseen by distributed grid algorithms.
                </p>
              </div>

              <div className="p-4 bg-black/40 border border-emerald-500/20 rounded-2xl hover:border-emerald-500/40 hover:bg-black/60 transition-all duration-300 backdrop-blur-md">
                <div className="flex items-center gap-2 mb-2">
                  <Sparkles className="text-neon-mint w-4 h-4 animate-pulse" />
                  <span className="font-label-sm text-xs font-bold text-white uppercase">Green-Vital</span>
                </div>
                <p className="text-white/70 text-xs">
                  Real-time health measurements ensure transparent, traceable tracking of reforestation parameters.
                </p>
              </div>

              <div className="p-4 bg-black/40 border border-emerald-500/20 rounded-2xl hover:border-emerald-500/40 hover:bg-black/60 transition-all duration-300 backdrop-blur-md">
                <div className="flex items-center gap-2 mb-2">
                  <Globe className="text-neon-mint w-4 h-4 animate-pulse" />
                  <span className="font-label-sm text-xs font-bold text-white uppercase">Terra-Plus</span>
                </div>
                <p className="text-white/70 text-xs">
                  A verification protocol rewarding diverse biodiversity actions and natural restoration with digital nodes.
                </p>
              </div>

              <div className="p-4 bg-black/40 border border-emerald-500/20 rounded-2xl hover:border-emerald-500/40 hover:bg-black/60 transition-all duration-300 backdrop-blur-md">
                <div className="flex items-center gap-2 mb-2">
                  <HeartHandshake className="text-neon-mint w-4 h-4 animate-pulse" />
                  <span className="font-label-sm text-xs font-bold text-white uppercase">Solar-Comm</span>
                </div>
                <p className="text-white/70 text-xs">
                  Democratized sustainable heat, light, and power sharing patterns for localized energy sovereignty.
                </p>
              </div>

            </div>

            <div className="flex justify-between items-center bg-black/55 border border-emerald-500/25 p-4 rounded-2xl backdrop-blur-md shadow-[inset_0_2px_10px_rgba(0,0,0,0.5)]">
              <span className="text-xs font-label-sm text-neon-mint font-extrabold tracking-wider">
                READY TO COMMENCE ACTIVATION?
              </span>
              <button 
                onClick={() => setShowEcosystemModal(false)}
                className="px-5 py-2.5 bg-gradient-to-r from-neon-mint to-forest-mint hover:scale-105 text-primary font-label-sm text-xs font-extrabold uppercase tracking-widest rounded-xl transition-all flex items-center gap-1 cursor-pointer shadow-[0_0_20px_rgba(116,198,157,0.3)] hover:shadow-[0_0_30px_rgba(116,198,157,0.65)]"
              >
                Let&apos;s Go
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
