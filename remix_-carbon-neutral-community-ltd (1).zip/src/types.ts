export interface FloatingNodeData {
  id: string;
  title: string;
  description: string;
  iconName: 'Leaf' | 'Activity' | 'Globe' | 'Sun';
  positionStyle: {
    top: string;
    left?: string;
    right?: string;
    bottom?: string;
  };
  speed: number;
}

export interface Contributor {
  email: string;
  nodeId: string;
  joinedAt: string;
}
